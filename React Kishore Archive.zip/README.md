# User-Selection

## To start the project follow the following commands
### npm install
### npm start
